<?php
/* banner-php */
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */
get_header(); ?>

<!--  section  --> 
<section class="parallax-section password-sec" data-scrollax-parent="true" id="sec1">
    <div class="bg par-elem "  data-bg="<?php echo esc_url(citybook_get_option('error404_bg'));?>" data-scrollax="properties: { translateY: '30%' }"></div>
    <div class="overlay"></div>
    <div class="bubble-bg"></div>
    <div class="container">
        <div class="protected-wrap">
            <h2 class="protected-text"><?php the_title( );?></h2>
            <?php echo get_the_password_form(); ?>
        </div>
    </div>
</section>
<!--  section  end--> 
<?php     
get_footer();
