<?php
/* banner-php */
//http://proteusthemes.github.io/one-click-demo-import/
//https://wordpress.org/plugins/one-click-demo-import/

function citybook_import_files() {
    return array(
        array(
            'import_file_name'             => esc_html__('CityBook theme - Full Demo Content (widgets included)','citybook' ),
            'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo_data_files/all-content.xml',
            'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo_data_files/widgets.wie',
            'import_notice'                => esc_html__( 'CityBook theme - Full Demo Content (widgets included)', 'citybook' ),
        ),

        array(
            'import_file_name'             => esc_html__('CityBook V2 - Listing Types','citybook' ),
            'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo_data_files/listing-types.xml',
            // 'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo_data_files/widgets.wie',
            'import_notice'                => esc_html__( 'This is demo listing types. After import this you have to go to Settings -> CityBook Add-Ons -> Submit tab to set default listing type for your site.', 'citybook' ),

            'import_preview_image_url'      => 'http://docs.cththemes.com/wp-content/uploads/2019/03/listing_types.png',
        ),

    );
}
add_filter( 'pt-ocdi/import_files', 'citybook_import_files' );