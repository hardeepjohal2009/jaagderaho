<?php
/* banner-php */
/**
 * Template Name: Fullwidth
 *
 */

if ( post_password_required() ) {
    get_template_part( 'template-parts/page/protected', 'page' );
    return;
}

get_header(); 

$show_page_header = get_post_meta(get_the_ID(),'_cth_show_page_header',true );

if($show_page_header == 'yes') :
    $show_page_title = get_post_meta(get_the_ID(),'_cth_show_page_title',true );
?>
<!--section -->
<section class="parallax-section" data-scrollax-parent="true" id="sec1">
    <div class="bg par-elem"  data-bg="<?php echo esc_url( get_post_meta( get_the_ID(), '_cth_page_header_bg', true ) );?>" data-scrollax="properties: { translateY: '30%' }"></div>
    <div class="overlay"></div>
    <div class="container">
        <div class="section-title center-align">
            <?php if($show_page_title == 'yes') : ?>
            <h1 class="head-sec-title"><span><?php single_post_title();?></span></h1>
            <?php endif ; ?>
            <?php 
                echo wp_kses_post( get_post_meta(get_the_ID(),'_cth_page_header_intro',true ) );
            ?>
            <?php citybook_breadcrumbs(); ?>
            <span class="section-separator"></span>
        </div>
    </div>
    <div class="header-sec-link">
        <div class="container"><a href="#sec2" class="custom-scroll-link"><?php esc_html_e( 'Let\'s Start', 'citybook' ); ?></a></div>
    </div>
</section>
<!-- section end -->
<?php endif;?>

<?php
while ( have_posts() ) : the_post();

	get_template_part( 'template-parts/page/content', 'fullwidth-page' );

	// If comments are open or we have at least one comment, load up the comment template.
	if ( comments_open() || get_comments_number() ) :
		comments_template();
	endif;

endwhile; // End of the loop.
?>


<?php 
get_footer( );
