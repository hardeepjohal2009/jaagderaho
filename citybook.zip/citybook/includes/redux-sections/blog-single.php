<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('Blog Single', 'citybook'),
    'id'         => 'blog-single-optons',
    'subsection' => true,
    'fields' => array(

        array(
            'id'      => 'blog-single-sidebar-width',
            'type'    => 'select',
            'title'   => esc_html__('Sidebar Width', 'citybook'),
            'desc'       => esc_html__( 'Based on Bootstrap 12 columns.', 'citybook' ),
            'options' => array(
                '2' => esc_html__('2 Columns', 'citybook'),
        '3' => esc_html__('3 Columns', 'citybook'),
        '4' => esc_html__('4 Columns', 'citybook'),
        '5' => esc_html__('5 Columns', 'citybook'),
        '6' => esc_html__('6 Columns', 'citybook'),
            ),
            'default' => '4',
        ),

        array(
            'id'      => 'single_featured',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Featured Image', 'citybook'),
            'default' => true,

        ),
        array(
            'id'      => 'single_date',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Date', 'citybook'),
            'default' => true,

        ),
        array(
            'id'      => 'single_author',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Author', 'citybook'),
            'default' => false,

        ),

        array(
            'id'      => 'single_cats',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Categories', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'single_tags',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Tags', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'single_comments',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Comments', 'citybook'),
            'default' => false,

        ),

        array(
            'id'      => 'single_author_block',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Author Block', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'single_post_nav',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show post navigation', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'single_same_term',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Next/Prev posts should be in same category', 'citybook'),
            'default' => false,

        ),

          
    ),
));
