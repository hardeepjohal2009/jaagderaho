<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('Footer', 'citybook'),
    'id'         => 'footer-settings',
    'subsection' => false,
    
    'icon'       => 'el-icon-pencil',
    'fields' => array(
        array(
            'id'      => 'footer_logo',
            'type'    => 'image_id',
            'title'   => esc_html__('Footer Logo', 'citybook'),
            'default' => '',
        ),

        array(
            'id'      => 'footer_copyright',
            'type'    => 'textarea',
            'title'   => esc_html__('Copyright Text', 'citybook'),
            'default' => '<span class="ft-copy">&#169; CityBook 2019  /  All rights reserved. </span>',
        ),

        array(
            'id'      => 'footer_currencies',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show currencies switcher?', 'citybook'),
            'default' => true,

        ),


    ),
) );