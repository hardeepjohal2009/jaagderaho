<?php
/* banner-php */

Redux::setSection( $opt_name, array(
    'title' => esc_html__('404 Page', 'citybook'),
    'id'         => 'error-page-settings',
    'subsection' => false,
    
    'icon'       => 'el-icon-file-edit',
    'fields' => array(
        array(
            'id'      => 'error404_bg',
            'type'    => 'image_id',
            'title'   => esc_html__('Background Image', 'citybook'),
            'default' => '',
        ),

        array(
            'id' => 'error404_msg',
            'type' => 'textarea',
            'title' => esc_html__('Additional Message', 'citybook'),
            'default' => ''
        ),
        array(
            'id' => 'back_home_link',
            'type' => 'text',
            'title' => esc_html__('Back Home Link', 'citybook'),
            // 'desc' => esc_html__('', 'citybook'),
            'default' => esc_url( home_url('/' ) )
        ),

        array(
            'id'      => 'error404_btn',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show back Home', 'citybook'),
            'default' => true,

        ),


        
    ),
) );

