<?php
/* banner-php */

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Header Options', 'citybook'),
    'id'         => 'header-settings',
    'subsection' => false,

    'icon'       => 'el-icon-briefcase',
    'fields'     => array(

        array(
            'id'      => 'header_info',
            'type'    => 'textarea',

            'title'   => esc_html__('Header Contacts Info', 'citybook'),
            'desc'    => esc_html__('Enter header contacts info for your site. Notice: only visible on large screen.', 'citybook'),
            'default' => '',

        ),
        array(
            'id'      => 'show_fixed_search',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Search', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'show_mini_cart',
            'type'    => 'switch',
            'on'      => esc_html__('Yes', 'citybook'),
            'off'     => esc_html__('No', 'citybook'),
            'title'   => esc_html__('Show Cart', 'citybook'),
            'default' => true,

        ),

        array(
            'id'      => 'user_menu_style',
            'type'    => 'select',
            'title'   => esc_html__('Logged In Style', 'citybook'),
            'options' => array(
                'one' => esc_html__('Style One', 'citybook'),
                'two' => esc_html__('Style Two', 'citybook'),
            ),
            'default' => 'two',
        ),
    ),
));
